#include"PM.h"
#include<iostream>
#include"Mainmenu.h"

using namespace std;

int main(){

    Menu main;
    main.menu();
    
}
