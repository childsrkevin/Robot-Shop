#ifndef customer_h
#define customer_h

#include <iostream>
#include <string>
#include <vector>
#include "SA.h"
#include"Robotpart.h"
#include"PM.h"
using namespace std;

class customer
{
public:
    void customer_menu();
    void print_menu2();
    void print_orders();
    string input_name(string name);
    void getpart();
    
private:
    vector<string> name;
    int number_customers;
    PM pm;
    Robotpart p;
};
#endif /* customer_h */
