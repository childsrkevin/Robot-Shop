#include "customer.h"
#include "PM.h"
#include "SA.h"
#include<iostream>
#include<string>


using namespace std;
using std::string;
using std::getline;

string customer::input_name(string a)
{
    cout<<"Enter Your Name: ";
    cin.ignore();
    getline(cin,a);
    return a;
}
void customer::print_menu2()
{
    int x;
    cout<<"\nEnter Designated Number From Menu"<<'\n';
    cout<<"1) View catalog of robots"<<'\n';
    cout<<"2) View Order"<<'\n';
    cout<<"3) View Outstanding Bill"<<'\n';
    cout<<"0) To Return To Main Menu"<<'\n';
 
    cin >> x;
    cin.ignore();
    
    if(x == 1)
        p.printmodel();
}
void customer::print_orders()
{
 /*   int sales = s.return_sales();
    for(int i=0;i< sales;i++)
    {
        
    }*/
}
void customer::customer_menu()
{
    int x=0;
    string input,a = "";
    
    cout<<"\nEnter Designated Number From Menu"<<'\n';
    cout<<"1) If You Are a New Customer"<<'\n';
    cout<<"2) If You Are a Returning Customer"<<'\n';
    cout<<"0) To Return To Main Menu"<<'\n';
    cin>> x;
    if(x==1)
    {
        input = input_name(a);
        name.push_back(input);
        number_customers ++;
    }
    else if(x==2)
    {
        cout<<"Enter your name: ";
        cin.ignore();
        getline(cin,a);
    }
    while(x!=0)
    {
        print_menu2();
        cin>> x;
        if(x==1)
        {
           // model.print();
        }
        else if(x==2)
        {
            print_orders();
        }
        else if(x==3)
        {
                        
        }
    }
}


void customer :: getpart(){
     p = pm.getpart();
}
