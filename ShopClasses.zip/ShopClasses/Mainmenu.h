#ifndef _MAINMENU_H
#define _MAINMENU_H
#include"PM.h"
#include"customer.h"
#include"SA.h"
#include<iostream>

using namespace std;

class Menu{
    private:
        PM pm;
        SA sa;
        customer c;
    public:
        void menu();
};
  
#endif // _MAINMENU_H
