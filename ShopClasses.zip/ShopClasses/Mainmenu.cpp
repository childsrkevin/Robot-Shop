#include"Mainmenu.h"
#include"PM.h"
#include"SA.h"
#include"customer.h"
#include<iostream>

using namespace std;

void Menu :: menu(){
    int x;
    cout << "=====Welcome to Robbie Robot Shop!=====" <<endl;
    cout << "1) PM" << endl;
    cout << "2) Beloved Customer" << endl;
    cout << "3) Sales Associate" << endl;
    cout << "4) Pointed Haired Boss" << endl;
    cout << "0) Quit" << endl;

    cin >> x;
    cin.ignore();
 
    if(x == 1)
        pm.menu();
    else if(x == 2)
        c.customer_menu();
    else if(x == 3)
        sa.menu();
    else if(x == 0)
        return;
    menu();
}
