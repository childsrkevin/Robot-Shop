#include"PM.h"
#include <stdio.h>
#include <iostream>
#include "SA.h"

string SA::input_name(string a)
{
    cout<<"Enter Your Name: ";
    cin.ignore();
    getline(cin,a);
    return a;
}
int SA::return_sales()
{
    return num_sales;
}
void SA::menu2()
{
    cout<<"\nEnter Designated Number From Menu"<<'\n';
    cout<<"1)Make an Order"<<'\n';
    cout<<"2)View Sales Report"<<'\n';
    cout<<"0)Return to Main Menu"<<'\n';
}
void SA::menu()
{
    int choice=0, order_num, model1, quantity1;
    double price1;
    string input,a = "",cus_name, date1;

    cout<<"Enter Designated Number From Menu"<<'\n';
    cout<<"1)New Sales Associate"<<'\n';
    cout<<"2)Returning Sales Associater"<<'\n';
    cin>> choice;
    
    if (choice == 1)
    {
        input = input_name(a);
        sellers.push_back(input);
        num_sellers++;
    }
    else if(choice == 2)
    {
        input = input_name(a);
    }
    while(choice!=0)
    {
        menu2();
        cin>> choice;
        if(choice==1)
        {
            num_sales++;
            order_seller.push_back(input);
            
            cout<<"Enter Customers Name:"<<'\n';
            cin.ignore();
            getline(cin,cus_name);
            c_name.push_back(cus_name);

            cout<<"Enter Order Number:"<<'\n';
            cin>>order_num;
            order_number.push_back(order_num);
            
            cout<<"Enter Date Of Sale:"<<'\n';
            cin.ignore();
            getline(cin,date1);
            date.push_back(date1);

            cout<<"Enter Robot Model:"<<'\n';
            cin>>model1;
            model.push_back(model1);

            cout<<"Enter Quantity:"<<'\n';
            cin >>quantity1;
            quantity.push_back(quantity1);

            cout<<"Enter Price:"<<'\n';
            cin >> price1;
            price.push_back(price1);

        }
        else if(choice==2)
        {
            for(int i =0 ;i<num_sales;i++)
            {
                if(input == order_seller[i])
                {
                    cout<<"Order Number:"<<order_number[i]<<"  Customer: "<<c_name[i]<<"  Date: "<<date[i]<<"  Model: "<<model[i]<<"  Quanity: "<<quantity[i]<<"  Price"<<price[i]<<'\n';
                }
            }
        }

    }
    
}


