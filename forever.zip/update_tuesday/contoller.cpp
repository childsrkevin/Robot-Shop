#include "Controller.h"
#include "customer.h"
#include "View.h"
#include "Database.h"
#include "Part.h"
#include<iostream>
#include<string>
#include "PM.h"
#include "SA.h"

using namespace std;

void Controller::cli(){
    int cmd = -1;
    while (cmd != 0)
    {
        view.show_menu();
        cout << "Command? ";
        cin >> cmd;
        cin.ignore();
        execute_cmd(cmd);
    }
}

void Controller::execute_cmd(int cmd)
{
    int choice=0;
    string input;
    
    if(cmd == 1)//go to pm
    {
        pm.menu();
    }
    else if(cmd == 2)
    {
        int x=0;
        string input,a = "";
        
        view.customer_menu();
        cin>>x;
        cin.ignore();
        if(x==1)
        {
            cout<<"Enter Your Name: ";
            getline(cin,a);
            
            c.input_name1(a);
        }
        else if(x==2)
        {
            cout<<"Enter your name: ";
            getline(cin,a);
        }
        while(x!=0)
        {
            c.print_menu2();
            cin>> x;
            cin.ignore();
            if(x==1)
            {
                pm.printmodels();
            }
            else if(x==2)
            {
                s.print_cus_order(a);
            }
            else if(x==3)
            {
                
            }
        }
    }
    
    else if(cmd == 3)
    {
        view.sales_menu();
        cin>> choice;
        cin.ignore();
        
        if (choice == 1)
        {
            cout<<"Enter Your Name: ";
            getline(cin,input);
            s.input_name1(input);
        }
        else if(choice == 2)
        {
            cout<<"Enter Your Name: ";
            getline(cin,input);
        }
        while(choice!=0)
        {
            s.menu2();
            cin>> choice;
            cin.ignore();
            if(choice==1)
            {
                s.create_order(input);
            }
            else if(choice==2)
            {
                s.print_order(input);
            }
      
        }
    }
    else if(cmd == 4)
    {
        int choice=0;
        view.boss_menu();
        cin>>choice;
        cin.ignore();
        if(choice==1)
        {
            vector<string> models=pm.return_mod_name();
            vector<double> price=pm.return_mod_price();
            vector<double> total_cost=pm.return_mod_totalcost();
            b.mp(models, price, total_cost);
            
        }
        else if(choice==2)
        {
            vector<string> models=pm.return_mod_name();
            vector<string> modnamesold = s.return_model_name();
            b.totalsold(models, modnamesold);
        }
        else if(choice==3)
        {
            s.print_all_orders();
        }
        else if(choice ==4)
        {
            vector<string> seller = s.return_seller();
            vector<string> quantity_sold= s.return_quantity_sold();
            b.salesass(seller,quantity_sold);
        }
    }
}
