#ifndef _DATABASE_H
#define _DATABASE_H
#include<iostream>
#include<string>
#include<vector>

using namespace std;

class Database
{
public:

private:
};

#endif
