#include"View.h"
#include<iostream>
#include<string>

using namespace std;

void View::show_menu()
{
    cout << endl << endl;
    cout << "==========" << endl;
    cout << "Main Menu" << endl;
    cout << "==========" << endl;
    cout << endl;
    cout << "Product Manager" << endl;
    cout << "---------------" << endl;
    cout << "(1) Product Manager" << endl;
    cout << "(2) Beloved Customer" << endl;
    cout << "(3) Sales Associate" << endl;
    cout << "(0) Exit" << endl;


}
void View::sales_menu()
{
    cout<<"Enter Designated Number From Menu"<<'\n';
    cout<<"1)New Sales Associate"<<'\n';
    cout<<"2)Returning Sales Associater"<<'\n';
}
void View::customer_menu()
{
    cout<<"\nEnter Designated Number From Menu"<<'\n';
    cout<<"1) If You Are a New Customer"<<'\n';
    cout<<"2) If You Are a Returning Customer"<<'\n';
    cout<<"0) To Return To Main Menu"<<'\n';
}

/*void View::show_PM_menu() {
 cout << endl << endl;
 cout << "====================" << endl;
 cout << "Product Manager Menu" << endl;
 cout << "====================" << endl;
 cout << endl;
 cout << "(1) Create a Part" << endl;
 cout << "(2) Print all Parts" << endl;
 }*/

void View::list_parts()
{
    cout << endl;
    cout << "-------------" << endl;
    cout << "List of Parts" << endl;
    cout << "-------------" << endl;
    for(int i = 0; i < database.number_of_parts(); ++i){
        cout << i << ") " << database.part_to_string(i) << endl;}

}
