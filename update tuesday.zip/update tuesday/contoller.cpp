#include "Controller.h"
#include "customer.h"
#include "View.h"
#include "Database.h"
#include "Part.h"
#include<iostream>
#include<string>
#include "PM.h"
#include "SA.h"

using namespace std;

void Controller::cli(){
    int cmd = -1;
    while (cmd != 0)
    {
        view.show_menu();
        cout << "Command? ";
        cin >> cmd;
        cin.ignore();
        execute_cmd(cmd);
    }
}

void Controller::execute_cmd(int cmd)
{
    int choice=0;
    string input;
    
    if(cmd == 1)//go to pm
    {
        pm.pm_menu();
        cout << "Command? ";
        cin >> cmd;
        cin.ignore();
    }
    else if(cmd == 2)
    {
        int x=0;
        string input,a = "";
        
        view.customer_menu();
        cin>>x;
        if(x==1)
        {
            cout<<"Enter Your Name: ";
            cin.ignore();
            getline(cin,a);
            
            c.input_name1(a);
        }
        else if(x==2)
        {
            cout<<"Enter your name: ";
            cin.ignore();
            getline(cin,a);
        }
        while(x!=0)
        {
            c.print_menu2();
            cin>> x;
            if(x==1)
            {
                view.list_parts();
            }
            else if(x==2)
            {
                s.print_cus_order(a);
            }
            else if(x==3)
            {
                
            }
        }
    }
    
    else if(cmd == 3)
    {
        view.sales_menu();
        cin>> choice;
        
        if (choice == 1)
        {
            cout<<"Enter Your Name: ";
            cin.ignore();
            getline(cin,input);
            s.input_name1(input);
        }
        else if(choice == 2)
        {
            cout<<"Enter Your Name: ";
            cin.ignore();
            getline(cin,input);
        }
        while(choice!=0)
        {
            s.menu2();
            cin>> choice;
            if(choice==1)
            {
                s.create_order(input);
            }
            else if(choice==2)
            {
                s.print_order(input);
            }
      
        }
    }
}


/*void Controller::execute_PM_cmd(int cmd) {
	if (cmd == 1) // Add part
	{
 string type, name, description;
 int number;
 double cost, weight;
 
 cout << "Type? ";
 getline(cin, type);
 
 cout <<  "Name? ";
 getline(cin, name);
 
 cout << "Description? ";
 getline(cin, description);
 
 cout << "Part Number? ";
 cin >> number;
 cin.ignore();
 
 cout << "Cost? ";
 cin >> cost;
 cin.ignore();
 
 cout << "Weight in Pounds? ";
 cin >> weight;
 cin.ignore();
 
 database.add_part(Part(type, description, name, number, cost, weight));
 
	}
	else if(cmd == 2) //Print Parts
 {
 view.list_parts();
 }
 }*/
