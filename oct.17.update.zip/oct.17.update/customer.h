#ifndef customer_h
#define customer_h

#include <iostream>
#include <string>
#include <vector>
#include"Database.h"
#include "View.h"
#include "Controller.h"
#include "SA.h"


using namespace std;

class customer
{
public:
    void customer_menu();
    void print_menu2();
    void print_orders();
    string input_name(string name);
    
private:
    vector<string> name;
    int number_customers;
};
#endif /* customer_h */
