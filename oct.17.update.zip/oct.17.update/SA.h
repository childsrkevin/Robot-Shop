#ifndef SA_h
#define SA_h

#include <iostream>
#include <string>
#include <vector>
#include"Database.h"
#include "View.h"
#include "Controller.h"
#include "Part.h"

using namespace std;

class SA
{
public:
    int return_sales();
    string input_name(string name);
    void menu2();
    void menu();
    
private:
    vector<string> sellers;
    vector<string> order_seller;
    vector<string> c_name;
    vector<string> date;
    vector<int> order_number;
    vector<int> model;
    vector<int> quantity;
    vector<double> price;
    int num_sellers = 0;
    int num_sales = 0;
    
};
#endif /* SA_h */
