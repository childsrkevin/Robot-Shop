#include "controller.h"
#include "customer.h"
#include "View.h"
#include "Database.h"
#include "Part.h"
#include "PM.h"
#include "SA.h"

#include<iostream>
#include<string>



using namespace std;
using std::string;
using std::getline;

void customer::input_name1(string a)
{
    name.push_back(a);
    number_customers ++;
}
void customer::print_menu2()
{
    cout<<"\nEnter Designated Number From Menu"<<'\n';
    cout<<"1) View catalog of robots"<<'\n';
    cout<<"2) View Order"<<'\n';
    cout<<"3) View Outstanding Bill"<<'\n';
    cout<<"0) To Return To Main Menu"<<'\n';
}



